package parserNodes;

public class EofNode {
}
